package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class homepage {
	WebDriver driver;
	
	@FindBy(xpath="//a[@class='blockbestsellers']")
	public WebElement SectionName;
	
	@FindBy(xpath="//span[@id='our_price_display']")
	public WebElement QV_ProductPrice;
	
	@FindBy(xpath="//h1[@itemprop='name']")
	public WebElement QV_ProductNameHeader;
	
	@FindBy(xpath="//p[@id='add_to_cart']/button/span")
	public WebElement QV_AddToCart;
	
	@FindBy(xpath="//h2[i[@class='icon-ok']]")
	public WebElement QV_AddedToCartMessage;
	
	@FindBy(xpath="//span[@class='ajax_block_products_total']")
	public WebElement QV_ProductTotal;
	
	@FindBy(xpath="//span[@class='ajax_cart_shipping_cost']")
	public WebElement QV_ProductShippingCost;
	
	@FindBy(xpath="//span[@class='ajax_block_cart_total']")
	public WebElement QV_ProductCartTotal;
	
	@FindBy(xpath="//span[@id='layer_cart_product_title']")
	public WebElement QV_ProductTitle;
	
	@FindBy(xpath="//span[@class='ajax_cart_product_txt ']")
	public WebElement QV_ProductCartQuantity;
	
	@FindBy(xpath="//span[@id='layer_cart_product_price']")
	public WebElement QV_SuccessMessageProductPrice;
	
	@FindBy(xpath="//span[@class='continue btn btn-default button exclusive-medium']")
	public WebElement QV_ContinueShopping;
	
	@FindBy(xpath="//span[@class='remove_link']/a[@class='ajax_cart_block_remove_link']")
	public WebElement CartHover_RemoveProductViaCross;
	
	@FindBy(xpath="//a[@title='View my shopping cart']")
	public WebElement CartHover;

	@FindBy(xpath="//a[@class='cart_block_product_name']")
	public WebElement CartHover_ProductName;
	
	@FindBy(xpath="//span[@class='ajax_cart_no_product']")
	public WebElement CartHover_NOProduct;
	
	//@FindBy(xpath="//a[@title='Printed Chiffon Dress']")
	//public WebElement productName;
	
	//@FindBy(xpath="//a[@title='Printed Chiffon Dress']/img[@title=")
	//public WebElement productImage;
	
	public homepage(WebDriver driver) {
			this.driver=driver;
			PageFactory.initElements(driver,this);
	}
	public WebElement quickviewProduct(String ProductName) {
		return driver.findElement(By.xpath("//a[@title='Printed Chiffon Dress' and @class='product-name']/following-sibling::div/following-sibling::a/span[contains(text(),'Quick view')]"));
	}
	public WebElement ProductImage(String ProductName) {
		return driver.findElement(By.xpath("//ul[@id='blockbestsellers']/li/div/div/div/a/img[@alt='"+ProductName.toString()+"']"));
	}
	public WebElement ProductLink(String ProductName) {
		return driver.findElement(By.xpath("//ul[@id='blockbestsellers']/li/div/div/div/a[@title='"+ProductName.toString()+"']"));
	}
	
	public WebElement ProductQV_Image(String ProductName) {
		return driver.findElement(By.xpath("xpath=//span[@id='view_full_size']/img[@alt='"+ProductName.toString()+"']"));
	}
}
