package testcases;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.ProductPage;
import pages.cartpage;
import pages.homepage;
import utils.gen_methods;
import utils.testbase;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;

public class testsuiteb {
  

	@Test
	public void testscenario2() throws SQLException, InterruptedException {
		 Connection conn=null;
		  Statement stment =null;
				  ResultSet rs = null;
	  WebDriver driver=null;
	  boolean FieldStatus=false;
	  try
		    {
			  System.out.println();
			 		  Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		        conn=DriverManager.getConnection("jdbc:ucanaccess://"+System.getProperty("user.dir") +"//Testdata//AccessDB.accdb");
		        stment = conn.createStatement();
		        String qry = "SELECT * FROM testscenario2 left outer join environment on (testscenario2.environment=environment.environment_name) where testscenario2.runflag='yes'";

		        rs = stment.executeQuery(qry);
		        while(rs.next())
		        {
		        	 String id    = rs.getString("ID");
		        	 String browsername = rs.getString("browsername");
			         String url= rs.getString("url");
			         String ProductName=rs.getString("productname");
			         String exp_strProductPrice=rs.getString("our_price_display");
			         String exp_stroldprice=rs.getString("old_price");
			         String exp_strreduction_Amount=rs.getString("reduction_amount");
			         String strSucessMessage=rs.getString("message");
			         String strQuantity=rs.getString("quantityvalue");
			          
			         /************************************************************************************************
  			            *   Test Scenario-2 (Firefox):
						*	1) Navigate to http://automationpractice.com/index.php
						*   2) Click on "BEST SELLERS"(TD) and click on "Blouse"(TD) 
						*           image and verify the details on the "Product" page as done in scenario-1.
						*   3) Increase the Quantity by 2 and click on "add to cart"
						*   4) Navigate to "Product" from "Cart" and Verify the details 
						*        like Description, Avail, UnitPrice, Quantity and Total and click on "Proceed to Checkout".

			          */
			         //*****************Step#1**************************
			         driver=testbase.launchBrowser(browsername);
			           driver.get(url.toString().replace("#", ""));
			           Actions actions = new Actions(driver);
			          
			         //*****************Step#2**************************
			           homepage homepagepf=new homepage(driver);
			          homepagepf.SectionName.click();
			         Thread.sleep(3000);
			         SoftAssert softassert=new SoftAssert();			         
			          JavascriptExecutor js=(JavascriptExecutor) driver;
			          WebElement element=homepagepf.ProductImage(ProductName);
			          js.executeScript("window.scrollBy(0,550);");
			          
			         // Thread.sleep(10000);
			       // actions.moveToElement(element).build().perform();
			        
			        Thread.sleep(2000);
			        element.click();
			        Thread.sleep(10000);
			        //driver.switchTo().frame(1);
			        
			        //***********************************Step#3****************************
			        ProductPage productpagepf=new ProductPage(driver);
			        			        
			        WebDriverWait wait = new WebDriverWait(driver, 10);
					try {
						wait.until(ExpectedConditions.presenceOfElementLocated(By.id("quantity_wanted")));
						wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("quantity_wanted")));
						wait.until(ExpectedConditions.elementToBeClickable(By.id("quantity_wanted")));
					}catch(TimeoutException e) {
						System.out.println(e.getMessage());
					}
					
			        productpagepf.CP_ChangeQuantity.clear();
			        productpagepf.CP_ChangeQuantity.sendKeys(strQuantity.toString());
			        productpagepf.CP_ChangeQuantity.click();
			        FieldStatus=productpagepf.CP_ChangeQuantity.getAttribute("value").contains(strQuantity);
			        softassert.assertEquals(FieldStatus, true);
			        
			        //System.out.println("Product Price Quick View:"+homepagepf.QV_ProductPrice.getText());

			        System.out.println("Product Price Quick View:"+homepagepf.QV_ProductPrice.getText());
			        FieldStatus=homepagepf.QV_ProductPrice.getText().contains(exp_strProductPrice);
			        softassert.assertEquals(FieldStatus, true);
			        
			        System.out.println("Product Name Header Quick View:"+homepagepf.QV_ProductNameHeader.getText());
			        FieldStatus=homepagepf.QV_ProductNameHeader.getText().toLowerCase().contains(ProductName.toLowerCase());
			        softassert.assertEquals(FieldStatus, true);
			        			        
			       homepagepf.QV_AddToCart.click();
			       Thread.sleep(5000);
			       
			       //************************************************Step#4**********************************************
			       //driver.switchTo().frame(1);
			       driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			       System.out.println("Quick View - Added to Cart Message:"+ homepagepf.QV_AddedToCartMessage.getText());
			       System.out.println("**********************************");
			       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			       System.out.println("Quick View - Added to Cart Message Popup Product Total:"+ homepagepf.QV_ProductTotal.getText());
			       System.out.println("**********************************");
			       System.out.println("Quick View - Added to Cart Message Popup Product Shipping Cost:"+ homepagepf.QV_ProductShippingCost.getText());
			       System.out.println("**********************************");
			       System.out.println("Quick View - Added to Cart Message Popup Product Cart Total:"+ homepagepf.QV_ProductCartTotal.getText());
			       System.out.println("**********************************");
			       System.out.println("Quick View - Added to Cart Message Popup Product Title:"+ homepagepf.QV_ProductTitle.getText());
			       Thread.sleep(2000);
			       homepagepf.QV_ContinueShopping.click();
			       Thread.sleep(2000);
			       driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			      // driver.switchTo().defaultContent();
			       js.executeScript("window.scrollBy(0,-550);");
			       Thread.sleep(2000);
			       //homepagepf.CartHover.click();
			       WebElement element1=homepagepf.CartHover;
			       WebElement element2= homepagepf.CartHover_RemoveProductViaCross;
			       actions.clickAndHold(element1).build().perform();
			       System.out.println("**********************************");
			       System.out.println("Cart Hover Product Name"+ homepagepf.CartHover_ProductName.getText());
			       element1.click();
			       //actions.clickAndHold(element1).click(element2).click(element2).build().perform();
			       Thread.sleep(5000);
			       cartpage cartpagepf=new cartpage(driver);
			       System.out.println("**********************************");
			       System.out.println("Cart Avail"+ cartpagepf.CP_cartavailtext.getText());
			       System.out.println("**********************************");
			       System.out.println("Cart Product Name"+ cartpagepf.CP_productname.getText());
			       System.out.println("**********************************");
			       System.out.println("Cart UnitPrice"+ cartpagepf.CP_unitprice.getText());
			       System.out.println("**********************************");
			       System.out.println("Cart Quantity"+ cartpagepf.CP_Quantity_value.getAttribute("value"));
			       System.out.println("**********************************");
			       System.out.println("Cart total price without tax"+ cartpagepf.CP_TotalPriceWithoutTax.getText());
			       System.out.println("**********************************");
			       System.out.println("Cart full total price"+ cartpagepf.CP_WholeTotalPrice.getText());
			       js.executeScript("window.scrollBy(0,550);");
			       //Thread.sleep(20000);
			       cartpagepf.CP_proceedtocheckout_Link.click();
			      
			       //*************************Step Fails intentionally....*************************************
			       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			       FieldStatus=cartpagepf.AfterClickingProceedToCheckout.isDisplayed();
			    	Assert.assertEquals(FieldStatus, true);	   
			       
			    	
			    	//Scenario2:-homepagepf.ProductQV_Image(ProductName);
			       //homepagepf.CartHover_RemoveProductViaCross.click();
			       
			        // js.executeScript("arguments[0].scrollIntoView(true);", element);
			        //homepagepf.quickviewProduct(ProductName).click();  
			         /*	        	reports =ExtentReportManager.getReports();
		    		
		        	test = reports.createTest("scenario1_"+id);
		        	System.out.println(System.getProperty("user.dir"));
		    		
		    		test.log(Status.INFO, "Starting test case Login");
		    		//test.log(Status.FAIL, "404 error");
		    		// selenium takes screenshot and puts in screesnhot folder
		    		//test.addScreenCaptureFromPath("D:\\Ashish\\Temp.png", "404 Error");
		    		//Assert.fail("404 error");
		    		test.log(Status.INFO, "Opening Browser"+ fname);
		    		test.log(Status.INFO, "Logging In");
		    		test.log(Status.PASS, "Test Passed");
		           
	*/
			       System.out.println(id + browsername);
			         Thread.sleep(10000);
			   	     if(driver!=null) driver.close();
			        }
			        
			        
			    }
			    catch(Exception err)
			    {
			        System.out.println(err);
			        Date d = new Date();
					System.out.println(d.toString().replaceAll(":", "-"));
					String reportsFolder=d.toString().replaceAll(":", "-");
					gen_methods.TakeWebScreenshot(driver,System.getProperty("user.dir") +"//screenshots//testscenario2_"+reportsFolder+".png");
			    }
			  finally {
			 if(rs!=null) rs.close();
		     if(stment!=null) stment.close();
		     if(conn!=null) conn.close();
		     if(driver!=null) driver.close();
		}
		}

	@BeforeTest
  public void beforeTest() {
  }

}
