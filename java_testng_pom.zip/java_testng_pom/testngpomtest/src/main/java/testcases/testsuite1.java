package testcases;

import org.testng.annotations.Test;

import pages.homepage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;
import utils.testbase;
public class testsuite1 {
  
	@Test
	public void testscenario1() throws SQLException, InterruptedException {
		 Connection conn=null;
		  Statement stment =null;
				  ResultSet rs = null;
	  WebDriver driver = null;
		try
		    {
			  System.out.println();
			 		  Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		        conn=DriverManager.getConnection("jdbc:ucanaccess://"+System.getProperty("user.dir") +"//Testdata//AccessDB.accdb");
		        stment = conn.createStatement();
		        String qry = "SELECT * FROM testscenario1 left outer join environment on (testscenario1.environment=environment.environment_name) where testscenario1.runflag='yes'";

		        rs = stment.executeQuery(qry);
		        while(rs.next())
		        {
		        	 String id    = rs.getString("ID");
		        	 String browsername = rs.getString("browsername");
			         String url= rs.getString("url");
			         String ProductName=rs.getString("productname");
			         String exp_strProductPrice=rs.getString("our_price_display");
			         String exp_stroldprice=rs.getString("old_price");
			         String exp_strreduction_Amount=rs.getString("reduction_amount");
			         String strSucessMessage=rs.getString("message");
			         
			           driver=testbase.launchBrowser(browsername);
			           driver.get(url.toString().replace("#", ""));
			           Actions actions = new Actions(driver);
			           homepage homepagepf=new homepage(driver);
			          homepagepf.SectionName.click();
			         Thread.sleep(3000);
			         
			          JavascriptExecutor js=(JavascriptExecutor) driver;
			          WebElement element=homepagepf.ProductImage(ProductName);
			          js.executeScript("window.scrollBy(0,550);");
			          
			         // Thread.sleep(10000);
			       // actions.moveToElement(element).build().perform();
			        
			        Thread.sleep(2000);
			        element.click();
			        Thread.sleep(15000);
			        //webdriverwait wait or loop until true...
			        driver.switchTo().frame(1);
			        System.out.println("Product Price Quick View:"+homepagepf.QV_ProductPrice.getText());
			       System.out.println("Product Name Header Quick View:"+homepagepf.QV_ProductNameHeader.getText());
			       homepagepf.QV_AddToCart.click();
			       Thread.sleep(3000);
			       System.out.println("Quick View - Added to Cart Message:"+ homepagepf.QV_AddedToCartMessage.getText());
			       System.out.println("**********************************");
			       System.out.println("Quick View - Added to Cart Message Popup Product Total:"+ homepagepf.QV_ProductTotal.getText());
			       System.out.println("**********************************");
			       System.out.println("Quick View - Added to Cart Message Popup Product Shipping Cost:"+ homepagepf.QV_ProductShippingCost.getText());
			       System.out.println("**********************************");
			       System.out.println("Quick View - Added to Cart Message Popup Product Cart Total:"+ homepagepf.QV_ProductCartTotal.getText());
			       System.out.println("**********************************");
			       System.out.println("Quick View - Added to Cart Message Popup Product Title:"+ homepagepf.QV_ProductTitle.getText());
			       Thread.sleep(2000);
			       homepagepf.QV_ContinueShopping.click();
			       Thread.sleep(2000);
			       driver.switchTo().defaultContent();
			       js.executeScript("window.scrollBy(0,-550);");
			       Thread.sleep(2000);
			       //homepagepf.CartHover.click();
			       WebElement element1=homepagepf.CartHover;
			       WebElement element2= homepagepf.CartHover_RemoveProductViaCross;
			       actions.clickAndHold(element1).build().perform();
			       System.out.println("**********************************");
			       System.out.println("Cart Hover Product Name"+ homepagepf.CartHover_ProductName.getText());
			       element2.click();
			       //actions.clickAndHold(element1).click(element2).click(element2).build().perform();
			       Thread.sleep(5000);
			       
			       System.out.println("**********************************");
			       System.out.println("Cart Hover No Product empty"+ homepagepf.CartHover_NOProduct.getText());
			       
			       //Scenario2:-homepagepf.ProductQV_Image(ProductName);
			       //homepagepf.CartHover_RemoveProductViaCross.click();
			       
			        // js.executeScript("arguments[0].scrollIntoView(true);", element);
			        //homepagepf.quickviewProduct(ProductName).click();  
			         /*	        	reports =ExtentReportManager.getReports();
		    		
		        	test = reports.createTest("scenario1_"+id);
		        	System.out.println(System.getProperty("user.dir"));
		    		
		    		test.log(Status.INFO, "Starting test case Login");
		    		//test.log(Status.FAIL, "404 error");
		    		// selenium takes screenshot and puts in screesnhot folder
		    		//test.addScreenCaptureFromPath("D:\\Ashish\\Temp.png", "404 Error");
		    		//Assert.fail("404 error");
		    		test.log(Status.INFO, "Opening Browser"+ fname);
		    		test.log(Status.INFO, "Logging In");
		    		test.log(Status.PASS, "Test Passed");
		           
	*/
		            System.out.println(id + browsername);
		         Thread.sleep(10000);
		   	     if(driver!=null) driver.close();
		        }
		        
		        
		    }
		    catch(Exception err)
		    {
		        System.out.println(err);
		    }
		  finally {
		 if(rs!=null) rs.close();
	     if(stment!=null) stment.close();
	     if(conn!=null) conn.close();
	    
	}
	}

	@BeforeTest
  public void beforeTest() {
  }

}
