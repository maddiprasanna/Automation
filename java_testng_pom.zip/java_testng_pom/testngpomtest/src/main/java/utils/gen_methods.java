package utils;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.GeckoDriverService;
import org.apache.commons.io.FileUtils;

public class gen_methods {

	public static void TakeWebScreenshot(WebDriver driver,String filepath) {
		TakesScreenshot scrshot=((TakesScreenshot)driver);
		File SrcFile=scrshot.getScreenshotAs(OutputType.FILE);
		File DestFile=new File(filepath);
		try {
			FileUtils.copyFile(SrcFile,DestFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
