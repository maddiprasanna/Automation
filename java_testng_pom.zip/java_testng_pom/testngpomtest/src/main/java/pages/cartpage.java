package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class cartpage {
WebDriver driver;
	
	@FindBy(xpath="//tr[@class='cart_item last_item first_item address_0 odd']/td[@class='cart_avail']/span")
	public WebElement CP_cartavailtext;
	
	//productName, cartavail, unitprice, quantity, total
	
	@FindBy(xpath="//tr[@class='cart_item last_item first_item address_0 odd']/td[@class='cart_description']/p/a")
	public WebElement CP_productname;
	
	@FindBy(xpath="//tr[@class='cart_item last_item first_item address_0 odd']/td[@class='cart_unit']/span/span[@class='price']")
	public WebElement CP_unitprice;
	
	@FindBy(xpath="//tr[@class='cart_item last_item first_item address_0 odd']/td[@class='cart_quantity text-center']/input[@class='cart_quantity_input form-control grey']")
	public WebElement CP_Quantity_value;
	
	@FindBy(xpath="//td[@id='total_price_without_tax']")
	public WebElement CP_TotalPriceWithoutTax;
	
	@FindBy(xpath="//td[@id='total_price_container']/span[@id='total_price']")
	public WebElement CP_WholeTotalPrice;
	
	@FindBy(xpath="//a[@class='button btn btn-default standard-checkout button-medium' and @title='Proceed to checkout']")
	public WebElement CP_proceedtocheckout_Link;
	
	@FindBy(xpath="//h3[@class='page-subheading' and contains(text(),'Create an accountfailit')]")
	public WebElement AfterClickingProceedToCheckout;
	
	public cartpage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
}
